# 🎫 Discord Ticket Bot

Bot completo de tickets para Discord com painel interativo, sistema staff, logs e muito mais.

---

## 📦 Instalação

```bash
npm install
```

---

## ⚙️ Configuração

1. Copie `.env.example` para `.env`:
```bash
cp .env.example .env
```

2. Preencha o `.env`:
```env
DISCORD_TOKEN=seu_token_aqui
CLIENT_ID=id_do_seu_bot
GUILD_ID=id_do_seu_servidor
PORT=3000
```

---

## 🚀 Executando

### 1. Registrar comandos slash:
```bash
node deploy-commands.js
```

### 2. Iniciar o bot:
```bash
node index.js
# ou com nodemon para desenvolvimento:
npm run dev
```

---

## 📋 Comandos

| Comando | Descrição |
|---|---|
| `/criar-painel` | Abre o construtor interativo de painéis |
| `/editar-painel` | Lista, edita e gerencia painéis salvos |
| `/enviar-painel [id]` | Envia um painel para um canal |
| `/blacklist add @user` | Adiciona usuário à blacklist |
| `/blacklist remove @user` | Remove usuário da blacklist |

---

## 🎛️ Como criar um painel

1. Use `/criar-painel` em qualquer canal
2. Configure pelo menu interativo:
   - **Nome** — nome do painel
   - **Descrição** — mensagem exibida no ticket (suporta `{user}`, `{ticket}`, `{option}`)
   - **Cor** — cor do embed (hex)
   - **Tipo Canal** — canal de texto ou tópico de fórum
   - **Opções** — botões e/ou dropdown para abertura de tickets
   - **Cargos Staff** — cargos que podem ver/atender tickets
   - **Cargos Mod** — cargos que podem arquivar/fechar
   - **Cargos Revisão** — cargos notificados ao finalizar
   - **Msg Revisão** — mensagem customizada ao finalizar
   - **Canais** — log, staff, auxiliar, re-reivindicação, categorias
   - **Configurações** — blacklist, pedir motivo, arquivar, auto-fechar
3. Clique em **Salvar Painel**
4. Use `/enviar-painel [id]` para enviar ao canal desejado

---

## 🔘 Botões do Ticket

| Botão | Quem pode usar | Ação |
|---|---|---|
| 🔒 Fechar | Dono + Staff | Fecha/arquiva o ticket |
| 🙋 Reivindicar | Staff (atendimento) | Reivindica o ticket |
| ⚙️ Moderação | Staff (atendimento) | Abre dropdown de ações |

### Dropdown de Moderação:
| Opção | Ação |
|---|---|
| ✅ Finalizar Ticket | Remove usuário, pinga moderação para revisão |
| 🆘 Solicitar Auxiliar | Envia msg no canal auxiliar |
| 🔄 Solicitar Re-Reivindicação | Envia msg no canal de re-reivindicação |
| ➕ Adicionar Membro | Adiciona membro ao ticket via ID |
| ➖ Remover Membro | Remove membro do ticket via ID |

---

## 📊 Sistema de Log

Registra automaticamente:
- Criação de tickets
- Fechamento
- Arquivamento / Desarquivamento
- Reivindicação / Re-reivindicação
- Finalização
- Adição/remoção de membros
- Geração de transcript

---

## 🌐 Deploy no Render

1. Crie dois serviços no Render:
   - **Web Service** — para o keep-alive (porta 3000)
   - **Background Worker** — para o bot principal

2. Configure as variáveis de ambiente no painel do Render

3. O keep-alive em `/ping` mantém o bot ativo no plano gratuito

---

## 📁 Estrutura

```
discord-ticket-bot/
├── index.js               # Entry point
├── keep-alive.js          # Mini site Express
├── deploy-commands.js     # Registra slash commands
├── data/                  # JSONs (banco de dados local)
├── commands/              # Definições dos slash commands
├── handlers/              # Lógica dos tickets
├── systems/               # Sistemas complexos (builder, editor, autoclose)
└── utils/                 # Utilitários
```
